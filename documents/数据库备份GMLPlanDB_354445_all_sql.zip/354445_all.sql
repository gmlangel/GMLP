﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `BookLesson`;
CREATE TABLE `BookLesson` (
  `id` int(100) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '唯一ID，无实际意义',
  `cid` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '对应lessones表中课程信息ID， cid',
  `uid` int(100) unsigned zerofill NOT NULL COMMENT '对应user表中，用户id，uid',
  `remark` text COMMENT '备用',
  `isOwnner` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否是主讲',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bookid` (`id`) USING BTREE,
  KEY `cid` (`cid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='用户约课映射表';

insert into `BookLesson`(`id`,`cid`,`uid`,`remark`,`isOwnner`) values
(1,4,1,null,b'0'),
(2,4,2,null,b'0'),
(3,3,1,null,b'0'),
(4,3,2,null,b'0'),
(5,3,3,null,b'0'),
(6,1,2,null,b'0'),
(7,14,13,null,b'0'),
(8,11,13,null,b'0'),
(9,24,5,null,b'0'),
(10,25,6,null,b'1'),
(11,25,7,null,b'1'),
(12,25,8,null,b'0'),
(13,25,9,null,b'0'),
(14,25,10,null,b'0'),
(15,25,11,null,b'0'),
(16,25,12,null,b'0'),
(17,25,13,null,b'0'),
(18,25,14,null,b'0'),
(19,25,14,null,b'0'),
(20,25,15,null,b'0');
DROP TABLE IF EXISTS  `BusinessInfo`;
CREATE TABLE `BusinessInfo` (
  `id` int(32) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '无实际意义',
  `bid_str` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '0' COMMENT '对应BusinessUsers中的bid_str\n',
  `des` text NOT NULL COMMENT '企业描述\n',
  `bname` varchar(100) NOT NULL COMMENT '企业名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='企业信息表';

insert into `BusinessInfo`(`id`,`bid_str`,`des`,`bname`) values
(1,'3a4630f5-d4e3-4a87-a10b-1d9c1d9d','在线课堂333','北京julia在线'),
(2,'96d9866b-51e4-4c91-be5c-df060b60','nicai2','wode jiaoshi'),
(3,'0daeb1b3-9106-4d1f-a62d-546a5798','',''),
(4,'1b7e6f88-8a27-407f-bb5c-00718258','',''),
(5,'987f57fa-a4f8-4f46-9982-8ff65c3c','',''),
(6,'03cb6f63-9b22-46ef-bb73-43a19b42','','');
DROP TABLE IF EXISTS  `BusinessUsers`;
CREATE TABLE `BusinessUsers` (
  `bid` int(100) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '企业ID',
  `bid_str` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT 'bid所对应的str形式，用于一切的对外业务操作。唯一',
  `business_des` text NOT NULL COMMENT '企业描述，不超过2000字',
  `remark` text COMMENT '备用',
  `ln` varchar(32) NOT NULL DEFAULT '' COMMENT '登录名',
  `pwd` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '999999' COMMENT '密码',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `idx_id` (`bid`) USING HASH,
  UNIQUE KEY `idx_idstr` (`bid_str`) USING HASH,
  UNIQUE KEY `idx_ln` (`ln`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=10037 DEFAULT CHARSET=utf8 COMMENT='企业用户表';

insert into `BusinessUsers`(`bid`,`bid_str`,`business_des`,`remark`,`ln`,`pwd`) values
(10000,'bbd','北京大生知行科技有限公司',null,'67y','999999'),
(10001,'bsaa','北京大生在线科技有限公司',null,'c7','999999'),
(10003,'dsdd','""',null,'c5','999999'),
(10007,'assvv','miaoshu',null,'ccc2','999999'),
(10006,'asvv','miaoshu
',null,'c3','999999'),
(10008,'aas33s','gfff',null,'ccc','999999'),
(10009,'5a3e3b45-a9e9-4585-aa66-77c7cfde','这是描述',null,'aaa','bbb'),
(10025,'fd6f9b4d-f5b0-48f2-97e8-adb6cef9','ssaaa',null,'aas5','15333'),
(10023,'7869a28f-8c68-45e5-8fb3-2b615253','ssaaa',null,'aas2','15333'),
(10024,'ff23d93d-7c6f-46c7-ab91-e7cd93c6','ssaaa',null,'aas4','15333'),
(10026,'cb78c633-7d4b-4063-9475-46a0eb77','ccc',null,'abba','123'),
(10027,'ed852160-9018-4bc4-913e-17726d71','ccc',null,'abbad','123'),
(10028,'7d66eec7-86ff-4b0a-bec4-87875dc3','',null,'aggss','123'),
(10029,'3a4630f5-d4e3-4a87-a10b-1d9c1d9d','',null,'ag33','123'),
(10030,'fd451b9a-aebd-48dd-a33c-9095f831','',null,'aggs','123'),
(10031,'1183e43c-416a-41c4-b7c6-fd461223','',null,'aggs2','123'),
(10032,'96d9866b-51e4-4c91-be5c-df060b60','',null,'gml333','123'),
(10033,'0daeb1b3-9106-4d1f-a62d-546a5798','',null,'gml444','1234'),
(10034,'1b7e6f88-8a27-407f-bb5c-00718258','',null,'gml555','123'),
(10035,'987f57fa-a4f8-4f46-9982-8ff65c3c','',null,'gml64vv','123'),
(10036,'03cb6f63-9b22-46ef-bb73-43a19b42','',null,'abcde','abcde');
DROP TABLE IF EXISTS  `lessones`;
CREATE TABLE `lessones` (
  `cid` int(100) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '课程ID',
  `b_cid` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '课程对应的公司渠道内部的课程ID',
  `b_key` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '课程对应的公司渠道的bid_str',
  `b_lessonInfo` text NOT NULL COMMENT '来自于指定公司渠道的课程信息',
  `startTime` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '课程开始时间',
  `lessonTimeLengh` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '课程时长',
  `maxCap` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '课程最大容纳人数，值为0代表无限制',
  `maxLine` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '媒体最大连麦数，值为0代表无限制',
  `remark` text COMMENT '备用',
  `pid` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '对应projectinfo表中的pid',
  PRIMARY KEY (`cid`),
  UNIQUE KEY `idx_cid` (`cid`) USING HASH,
  KEY `b_idstr` (`b_key`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='课程信息表';

insert into `lessones`(`cid`,`b_cid`,`b_key`,`b_lessonInfo`,`startTime`,`lessonTimeLengh`,`maxCap`,`maxLine`,`remark`,`pid`) values
(1,'10086','bsaa','测试课程数据',0,0,0,0,null,0),
(2,'10087','bsaa','测试课程数据2',0,0,0,0,null,0),
(3,'10088','bsaa','测试课程数据3',0,0,0,0,null,0),
(4,'133','bbd','我是大生在线的数据',0,0,0,0,null,0),
(5,'19932','bsaa','测试课',0,100,100,5,null,0),
(13,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14),
(14,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14),
(25,'789789','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"teachingMaterialPath":"https://www.juliaol.cn/classroom/pdfs/4b7598199953ffe850ed9d672991ccc6.pdf"}',1545350400,1800,1000,1,null,14),
(10,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1544572800,1800,1000,16,null,14),
(11,'444','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者","age":"13"}',1544572801,1801,999,12,null,13),
(12,'111','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者423232"}',1543708800,1011,500,4,null,15),
(24,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14),
(23,'12345','03cb6f63-9b22-46ef-bb73-43a19b42','{"lesName":"爱国者","abcde":"abcde"}',1545868800,1800,1000,16,null,17),
(19,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14),
(20,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14),
(21,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14),
(22,'333','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','{"lesName":"爱国者"}',1545350400,1800,1000,16,null,14);
DROP TABLE IF EXISTS  `projectInfo`;
CREATE TABLE `projectInfo` (
  `pid` int(100) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '项目ID',
  `pname` varchar(100) NOT NULL DEFAULT '' COMMENT '项目名称',
  `bid_str` varchar(100) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '对应的公司或者机构的ID，BusinessUsers中的bid_str\n',
  `pdes` text NOT NULL COMMENT '项目描述',
  `remark` text NOT NULL COMMENT '备用',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `idx_pid` (`pid`) USING BTREE,
  KEY `to_bidstr` (`bid_str`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='公司下的项目信息存储表';

insert into `projectInfo`(`pid`,`pname`,`bid_str`,`pdes`,`remark`) values
(1,'我的项目','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','',''),
(6,'3a4630f5-d4e3-4a87-a10b-1d9c1d9d','???1','',''),
(5,'3a4630f5-d4e3-4a87-a10b-1d9c1d9d','???1','',''),
(4,'3a4630f5-d4e3-4a87-a10b-1d9c1d9d','???1','',''),
(7,'公开课1','96d9866b-51e4-4c91-be5c-df060b60','',''),
(8,'公开课1','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','',''),
(9,'公开课1','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','',''),
(10,'公开课1555','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','333',''),
(11,'公开课4','0daeb1b3-9106-4d1f-a62d-546a5798','给好多孩子上课',''),
(17,'abc','03cb6f63-9b22-46ef-bb73-43a19b42','abcde',''),
(13,'测试项目3','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','',''),
(14,'测试项目5','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','测试项目5','');
DROP TABLE IF EXISTS  `users`;
CREATE TABLE `users` (
  `uid` int(100) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `nickname` varchar(32) DEFAULT '' COMMENT '用户昵称',
  `b_Key` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '用户对应的公司渠道来源，外键对应BusinessUsers表中的bid_str\n',
  `b_uid` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '0' COMMENT '用户对应的所在公司渠道内部的ID映射',
  `createTime` int(100) unsigned zerofill NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' COMMENT '用户的创建时间，用于应对过期策略',
  `remark` text COMMENT '备用',
  `headerImage` varchar(100) NOT NULL COMMENT '用户头像url',
  `sex` bit(1) NOT NULL DEFAULT b'0' COMMENT '用户性别',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `id_uid` (`uid`) USING BTREE,
  KEY `businessMapping` (`b_Key`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='用户表';

insert into `users`(`uid`,`nickname`,`b_Key`,`b_uid`,`createTime`,`remark`,`headerImage`,`sex`) values
(1,'用户B','bbd','1',0,null,'',b'0'),
(2,'用户A','bsaa','1',0,null,'',b'0'),
(3,'用户C','bsaa','2',0,null,'',b'0'),
(4,'用户D','bsaa','3211',0,null,'',b'0'),
(5,'猫猫无所谓','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','799547',1545293389,null,'http://sswaa',b'1'),
(6,'A_20000','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20000',1545720667,null,'',b'0'),
(7,'A_20001','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20001',1545720684,null,'',b'0'),
(8,'A_20002','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20002',1545720692,null,'',b'0'),
(9,'A_20003','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20003',1545720703,null,'',b'0'),
(10,'A_20004','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20004',1545720708,null,'',b'0'),
(11,'A_20005','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20005',1545725190,null,'',b'0'),
(12,'A_20006','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20006',1545726440,null,'',b'0'),
(13,'A_20008','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20008',1545726569,null,'',b'0'),
(14,'20009','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20009',1545726613,null,'',b'0'),
(15,'A_20010','3a4630f5-d4e3-4a87-a10b-1d9c1d9d','20010',1545729027,null,'',b'0');
SET FOREIGN_KEY_CHECKS = 1;

